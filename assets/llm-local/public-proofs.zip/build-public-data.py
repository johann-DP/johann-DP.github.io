#!/usr/bin/env python3
"""Build only the explicit public projection of the closed synthetic V6 run.

Usage: python3 build-public-data.py --source-root PATH_TO_PRIVATE_CHECKOUT
Only the output directory is written. Existing exports are never overwritten.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess

COMMIT = "99070d77cb426dafb5efc2435eefd6e2dabe2224"
BASE = "evidence/solution-v6/"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def project(root):
    sources = {}

    def read(name, jsonl=False):
        raw = (root / name).read_bytes()
        sources[name] = digest(raw)
        return [json.loads(line) for line in raw.splitlines() if line.strip()] if jsonl else json.loads(raw)

    score = read(BASE + "acceptance-score-r1.json")
    contribution = read(BASE + "acceptance-contribution-r1.json")
    score01 = read(BASE + "acceptance-score.json")
    contribution01 = read(BASE + "acceptance-contribution-01.json")
    freeze = read(BASE + "final-selection.json")
    revision = read(BASE + "admission-selection.json")
    correction = read(BASE + "admission-correction.json")
    stop = read(BASE + "stop-during-request.json")
    operator = read(BASE + "operator-command-proof.json")
    inputs_name = "data/solution-v5/acceptance/inputs.jsonl"
    outputs_name = "runs/incident-v6-acceptance-02/outputs.jsonl"
    inputs = read(inputs_name, True)
    outputs = read(outputs_name, True)
    assert sources[inputs_name] == score["source_hashes"][inputs_name]
    assert sources[outputs_name] == score["source_hashes"][outputs_name]
    archive = read(BASE + "captures/manifest.json")
    archived = {entry["source"]: entry for entry in archive["files"]}
    assert archived[outputs_name]["original_sha256"] == sources[outputs_name]
    assert len(inputs) == len(outputs) == len(score["outcomes"]) == len(contribution["rows"]) == 30
    by_contribution = {row["id"]: row for row in contribution["rows"]}
    cases = []
    for index, (visible, outcome, scored) in enumerate(zip(inputs, outputs, score["outcomes"])):
        assert visible["id"] == outcome["id"] == scored["id"] and outcome["index"] == index
        assert visible["split"] == scored["split"]
        assert outcome["response"] == scored["response"]
        attributed = by_contribution[scored["id"]]
        assert attributed["compiled_score"] == scored["score"]
        verification = outcome["capture"]["http_document"]["trace"]["field_verification"]
        assert verification == attributed["field_verification"]
        cases.append({"id": scored["id"], "index": index, "split": scored["split"], "mode": scored["mode"],
                      "input": visible["input"], "response": scored["response"], "expected": scored["expected"],
                      "score": scored["score"], "wall_seconds": scored["wall_seconds"],
                      "field_verification": verification,
                      "raw_model_conform": attributed["raw_model_score"]["conform"] if attributed["raw_model_score"] else None})
    assert [c["index"] for c in cases if not c["score"]["conform"]] == [22, 23, 26, 29]

    def feature(index, key, title, explanation, focus_field, cause, quotes):
        case = cases[index]
        for quote in quotes:
            assert quote["quote"] in next(p["text"] for p in case["input"]["pieces"] if p["id"] == quote["piece"])
        return {"key": key, "index": index, "id": case["id"], "title": title,
                "explanation": explanation, "focus_field": focus_field, "cause": cause, "quotes": quotes}

    short = feature(6, "short_conform", "Un dossier court : quatre informations justifiées",
        "La liaison « ne transporte plus aucun paquet » : la fiche retient un problème de connectivité du réseau. Les pièces précisent qu’une seule personne est touchée et autorisent une prise en charge demain. Les quatre valeurs et les citations correspondent à l’annotation du test.",
        "category", "Les constats sont explicites et cohérents.",
        [{"piece": "P03", "quote": cases[6]["response"]["evidence"][1]["quote"]}, {"piece": "P05", "quote": cases[6]["response"]["evidence"][3]["quote"]}])
    long = feature(0, "long_conform", "Un dossier long : retrouver les preuves utiles",
        "Parmi 21 pièces, la fiche retient le stockage et un refus d’authentification. Elle cite dans EXP1 « Le résultat enregistré est « compte révoqué, ouverture refusée ». » et l’impact limité aux douze membres d’une équipe. Le traitement doit commencer aujourd’hui. Ces citations sont acceptées par la grille, même si l’annotation illustre aussi les preuves présentes dans P03 et P04.",
        "category", "Des passages pertinents sont retrouvés dans un dossier long.",
        [{"piece": e["piece"], "quote": e["quote"]} for e in cases[0]["response"]["evidence"]])
    negation = feature(22, "negation_error", "Une absence de constat devient une catégorie inventée",
        "La réponse annonce « disponibilite » en citant : « Aucun accès non autorisé ni activité suspecte n'a été constaté dans les vérifications de ce dossier. » Cette phrase écarte un constat de sécurité ; elle ne prouve pas une indisponibilité. Le dossier ajoute qu’aucune autre anomalie n’est établie. L’annotation laisse donc la catégorie inconnue et demande une précision ; la réponse obtenue ne le fait pas.",
        "category", "Une négation ne permet pas de choisir une autre panne.",
        [{"piece": "DOC2", "quote": cases[22]["response"]["evidence"][1]["quote"]},
         {"piece": "DOC1", "quote": "Le déclarant ne décrit aucun autre symptôme ; aucune autre anomalie n'est établie dans les pièces reçues."}])
    conflicts = feature(23, "two_conflicts_error", "Deux désaccords actuels disparaissent de la fiche",
        "Le journal conserve deux constats incompatibles, sans retrait : « une personne seulement rencontre l'incident » et « Tous les membres du groupe Accueil sont touchés ». Il accepte aussi un report à demain tout en demandant un début avant la fin de la journée. La réponse choisit une personne et aujourd’hui, sans signaler de contradiction. L’annotation exige de garder les deux désaccords et de demander une précision.",
        "impact", "Une seule version est retenue alors que les deux restent actuelles.",
        [{"piece": e["piece"], "quote": e["quote"]} for e in cases[23]["expected"]["evidence"] if e["field"] in ("impact", "urgency")])
    extra = feature(26, "extra_citation_error", "Les valeurs sont correctes, une citation supplémentaire est rejetée",
        "La réponse conserve bien les deux rattachements contradictoires de LYNX-416, laisse le service inconnu et demande une précision. Les quatre valeurs sont correctes. Elle ajoute toutefois P04 : « Les deux propriétaires maintiennent leurs rattachements pour cette même ressource ; aucun arbitrage ni remplacement n'est établi. » Cette phrase existe dans le dossier, mais la grille gelée ne l’accepte pas comme preuve du champ service. L’échec porte sur ce contrat de citations, pas sur une fausse citation ni une mauvaise valeur.",
        "service", "La grille rejette une citation de contexte supplémentaire.",
        [{"piece": e["piece"], "quote": e["quote"]} for e in cases[26]["response"]["evidence"] if e["field"] == "service"])
    urgency = feature(29, "urgency_conflict_error", "Un désaccord est repéré, le second est perdu",
        "La fiche signale correctement le désaccord sur les personnes touchées. Pour le délai, elle retient seulement « Une prise en charge sans délai est explicitement demandée pour cet incident. » Elle omet « La prise en charge est attendue cet après-midi, au plus tard ce soir. » Les deux correspondants maintiennent leurs constats. L’annotation conserve donc aussi une contradiction sur l’urgence, qui doit rester inconnue.",
        "urgency", "La contradiction sur le délai n’est pas conservée.",
        [{"piece": e["piece"], "quote": e["quote"]} for e in cases[29]["expected"]["evidence"] if e["field"] == "urgency"])

    events = []
    for proof in operator["proof"]:
        action = proof["action"]
        before = read(BASE + "operator-examples/" + action + "-before.json")
        after = read(BASE + "operator-examples/" + action + "-after.json")
        decision = read(BASE + "operator-examples/" + action + "-decision.json")
        assert before["proposal"] == after["proposal"]
        assert decision == after["decision"] == proof["event"]
        assert decision["simulated"] is True and decision["counts_as_real_human_review"] is False
        case = next(c for c in cases if c["id"] == proof["case_id"])
        initial = before["proposal"]["initial_result"]["http_document"]["response"]
        assert initial == case["response"] and before["proposal"]["input"] == case["input"]
        kept = {k: decision[k] for k in ("action", "actor", "reason", "evidence_review_acknowledged", "simulated", "counts_as_real_human_review", "changes", "final_response", "external_action", "status")}
        kept["timestamp"] = decision["utc"]
        events.append({"action": action, "timestamp": decision["utc"], "case_id": case["id"], "case_index": case["index"],
                       "initial": initial, "expected": case["expected"], "pieces": case["input"]["pieces"],
                       "changes": decision["changes"], "decision": kept, "simulated": True,
                       "initial_status": before["proposal"]["status"], "initial_created_utc": before["proposal"]["created_utc"],
                       "initial_unchanged": before["proposal"] == after["proposal"]})

    physical = contribution["resources"]
    resources = {k: physical[k] for k in ("scope", "observed_peak_temperature_all_events_c", "temperature_observations_all_events", "sampled_peak_temperature_c", "sampled_temperature_scope", "window_seconds", "samples", "unavailable_events", "metrics", "gpu_energy_observed_intervals_wh", "covered_seconds", "coverage_ratio", "leading_unobserved_seconds", "trailing_unobserved_seconds", "method", "thermal_throttling", "power_throttling", "power.limit", "cpu_total_rss_bytes")}
    resources["metric_units"] = {"memory.used": "MiB", "temperature.gpu": "°C", "power.draw": "W", "utilization.gpu": "%", "clocks.sm": "MHz", "clocks.mem": "MHz"}
    resources["gaps"] = [{k: gap[k] for k in ("seconds", "reason")} for gap in physical["gaps"]]
    resources["admission_pauses"] = {k: physical["admission_pauses"][k] for k in ("episodes_intersecting_window", "observed_or_clipped_seconds", "orphan_end_events", "scope")}
    resources["gpu_energy_counter"] = {k: physical["gpu_energy_counter"][k] for k in ("available_samples", "energy_wh", "covered_seconds")}
    memory = {k: v for k, v in contribution["memory"].items() if k != "source_log_excerpt"}
    measurements = {"latency_seconds": contribution["latency_seconds"], "memory": memory, "resources": resources,
                    "fan_mode": revision["configuration"]["fan_mode"],
                    "scope": "Recette V6r1 acceptance-02 uniquement, refroidissement et attente inclus. Mesures enregistrées, aucune nouvelle inférence."}
    stopped_client = json.loads(stop["client_stdout"])
    stop_public = {"intentional": True, "outside_acceptance_denominator": True,
                   "active_request_observed": stop["active_request_observed"]["active"] == 1,
                   "http_status": stopped_client["http_status"], "error": stopped_client["http_document"]["error"],
                   "client_returncode": stop["client_returncode"], "stop_command_returncode": stop["stop_command_returncode"],
                   "elapsed_seconds": stop["elapsed_seconds"], "client_output_is_error_not_success": stop["client_output_is_error_not_success"],
                   "ready_after": stop["server_result"]["ready"], "stop_reason": stop["server_result"]["stop_reason"],
                   "all_owned_groups_exited": all(row["group_exited"] for row in stop["server_result"]["cleanup"]),
                   "forced_termination_used": any(row["forced_kill"] for row in stop["server_result"]["cleanup"]),
                   "memory_within_baseline_plus_256_mib": stop["server_result"]["memory_within_baseline_plus_256_mib"],
                   "real_human_review_count": stop["real_human_review_count"]}
    freeze_keys = ("schema", "created_utc", "state", "parent_commit", "selected_candidate", "max_repairs", "seed", "temperature", "all_acceptance_cases_reused", "business_readiness", "real_human_review_count", "no_retuning_after_acceptance", "no_semantic_retuning_after_acceptance", "operational_revision", "parent_freeze_sha256")
    freezes = []
    for original in (freeze, revision):
        item = {k: original[k] for k in freeze_keys if k in original}
        item["configuration"] = {k: original["configuration"][k] for k in ("context", "dtype", "fan_mode", "kv_bytes", "max_sequences", "request_timeout")}
        item["acceptance"] = {k: original["acceptance"][k] for k in ("common_minimum_conform", "common_planned", "difficult_planned", "difficult_reported_separately")}
        item["source_file_hashes"] = {k: original[k] for k in ("production_files", "evaluation_files", "data_files")}
        freezes.append(item)
    history = {"acceptance01": {"planned": 30, "groups": score01["by_split"],
                "http_status_counts": contribution01["http_status_counts"], "error_code_counts": contribution01["error_code_counts"],
                "raw_model_not_executed": sum(r["raw_model_status"] == "NOT_EXECUTED" for r in contribution01["rows"]),
                "explanation": "La première recette conserve 5 réponses et 25 refus HTTP 503 avant inférence pendant la pause de refroidissement."},
                "admission_correction": {"utc": correction["utc"], "observed_responses": correction["observed_responses"],
                "observed_cooling_refusals": correction["observed_cooling_refusals"], "semantic_prompt_model_scoring_data_unchanged": correction["semantic_prompt_model_scoring_data_unchanged"],
                "explanation": "Deux contrôles frontaux refusaient les demandes avant l’attente thermique déjà prévue. La révision conserve cette attente bornée et les protections d’urgence, sans changement sémantique. Les 30 mêmes dossiers ont été rejoués ; la première recette reste conservée."},
                "intentional_stop": stop_public}
    limits = ["Les 30 dossiers sont synthétiques et réutilisés ; ils ne mesurent pas une généralisation indépendante.",
              "Les attentes affichées sont les annotations du test, jamais des réponses obtenues.",
              "Aucune revue humaine réelle n’est comptabilisée. Les trois décisions opérateur sont simulées.",
              "La conformité dépend d’une grille finie. Quatre réponses portent un signalement critique ; l’une a des valeurs correctes mais une citation supplémentaire rejetée.",
              "Les gains éventuels du post-traitement ne prouvent aucun nouvel apprentissage. Les mesures de temps sont celles de la réponse complète.",
              "L’énergie mesurée concerne la carte graphique ; les lacunes ne sont pas comblées. La consommation totale de la station et le temps métier gagné ne sont pas mesurés.",
              "Cette page rejoue des réponses enregistrées. Elle ne lance pas de modèle, ne valide pas automatiquement une proposition et n’exécute aucune action SI."]
    data = {"schema": "datapredict-synthetic-incident-public-v6/1", "title": "Assistant local de qualification d’incidents — recette V6r1",
            "provenance": {"source_commit": COMMIT, "source_sha256": sources, "public_projection": "Liste explicite de champs ; aucune capture privée brute ni prompt exporté."},
            "limits": limits,
            "summary": {"planned": 30, "responses": 30, "conform": sum(c["score"]["conform"] for c in cases),
                        "critical_responses": sum(bool(c["score"]["critical_errors"]) for c in cases),
                        "all_requests_counted": score["all_requests_counted"], "all_outcomes_within_135s": score["all_outcomes_within_135s"],
                        "human_review_count": 0, "reused_cases": 30, "independent_generalization": False,
                        "raw_model_conform": sum(c["raw_model_conform"] is True for c in cases),
                        "http_status_counts": contribution["http_status_counts"], "error_code_counts": contribution["error_code_counts"]},
            "groups": score["by_split"], "measurements": measurements, "cases": cases,
            "featured_cases": [short, long, negation, conflicts], "error_cases": [negation, conflicts, extra, urgency],
            "operator_demo": {"simulated": True, "real_human_review_count": 0, "external_action": False,
                              "initial_records_unchanged": operator["initial_records_unchanged"], "events": events},
            "history": history}
    proofs = {"score-acceptance02.json": {"schema": score["schema"], "by_split": score["by_split"],
               "outcomes": [{k: row[k] for k in ("id", "split", "mode", "score", "response_present", "response", "expected", "wall_seconds")} for row in score["outcomes"]],
               "initial_proposal_only": True, "human_review_count": 0, "reused_cases": 30, "independent_generalization": False},
              "freezes.json": {"projection": "Métadonnées et empreintes des deux gels ; chemins de fichiers relatifs, sans poids de modèle ni consignes.", "freezes": freezes},
              "operator-simulations.json": data["operator_demo"], "operational-history.json": history}
    return data, proofs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.source_root.resolve()
    actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
    assert actual == COMMIT, "source_commit_changed"
    data, proofs = project(root)
    from importlib.util import spec_from_file_location, module_from_spec
    spec = spec_from_file_location("public_verifier", Path(__file__).with_name("verify-public-data.py"))
    verifier = module_from_spec(spec)
    spec.loader.exec_module(verifier)
    result = verifier.verify(data, proofs)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "proofs").mkdir(exist_ok=True)
    for name, value in {"public-data.json": data, **{"proofs/" + n: v for n, v in proofs.items()}, "public-proof-check.json": result}.items():
        with (args.output / name).open("x", encoding="utf-8") as stream:
            stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
