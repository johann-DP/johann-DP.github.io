PROPOSITION PRIVÉE — PREUVES PUBLIQUES ASSAINIES DE LA RECETTE V6r1

Source figée : commit 99070d77cb426dafb5efc2435eefd6e2dabe2224.
Ce paquet contient 30 dossiers synthétiques déjà utilisés, leurs propositions
initiales enregistrées, les annotations du test et les scores exacts conservés.
Les indices commencent à 0. Les annotations ne sont jamais des réponses obtenues.
Aucune nouvelle inférence, aucun poids de modèle et aucune consigne applicative
ne sont inclus. Les pièces synthétiques peuvent contenir les instructions
trompeuses prévues par les cas difficiles ; elles restent des données à examiner.

RÉSULTAT ET PORTÉE
20/20 dossiers courants et 6/10 dossiers difficiles sont conformes à la grille
gelée. Les 30 tentatives restent dans les dénominateurs. Quatre réponses difficiles
portent un signalement critique : indices 22, 23, 26 et 29. L'indice 26 a les
quatre valeurs correctes et une abstention correcte ; une citation supplémentaire,
exacte mais non acceptée par le contrat de preuves, explique son échec.
Ces résultats ne constituent pas un test indépendant de généralisation ni une
validation métier. La présence littérale d'une citation ne prouve pas sa pertinence.

Zéro revue humaine réelle. Les événements confirm/correct/reject sont des
simulations techniques horodatées : indices 0, 22 et 20. Leurs changements exacts
sont conservés ; les propositions initiales restent inchangées. La correction
simulée utilise l'annotation synthétique gelée. Aucune action SI n'est exécutée.

HISTORIQUE CONSERVÉ
La première recette conserve ses 30 issues : 5 réponses et 25 refus HTTP 503
cooling_admission_paused, avant inférence. La révision mécanique d'admission a
rejoué les mêmes 30 dossiers, sans changer modèle, consignes, données ou notation.
Les deux gels sont fournis sous forme de métadonnées et d'empreintes assainies.
Un arrêt intentionnel pendant une demande active a produit un HTTP 503
service_stopping ; il est conservé séparément et n'entre pas dans les 30 dossiers.
Les groupes de processus détenus ont été arrêtés, avec terminaison forcée signalée.

MESURES
Les latences comprennent la réponse complète et ses attentes. L'énergie et les
températures sont des mesures enregistrées du GPU, pas de toute la station.
Les lacunes de couverture restent visibles. Mémoire totale de l'appareil,
chargement du modèle et réserve KV sont distingués ; les valeurs d'allocation
du moteur et de résidence de l'adaptateur non mesurées restent nulles.
Les scores bruts et finaux proviennent des mêmes demandes enregistrées : une
amélioration après traitement logiciel ne démontre aucun nouvel apprentissage.

FICHIERS
public-data.json : données de la page, 30 dossiers complets, quatre exemples,
les quatre erreurs, mesures, provenance SHA-256 et simulations opérateur.
proofs/score-acceptance02.json : projection assainie des scores et réponses exacts.
proofs/freezes.json : métadonnées et empreintes des deux gels.
proofs/operator-simulations.json : décisions simulées avec changements exacts.
proofs/operational-history.json : première recette, correction et arrêt intentionnel.
public-proof-check.json : contrôle interne de l'export.
source-verification.json : rapprochement exact avec les 21 fichiers sources lus.
SHA256SUMS-public.txt : empreintes des fichiers du paquet.

REJOUER LE CONTRÔLE PUBLIC — PYTHON 3, BIBLIOTHÈQUE STANDARD UNIQUEMENT
Depuis le dossier extrait :
    PYTHONDONTWRITEBYTECODE=1 python3 verify-public-data.py
Le contrôle vérifie les comptes, 123 citations de réponses, 125 citations des
annotations, 24 citations d'explications et 7 citations de décisions simulées,
les changements opérateur et l'absence des champs opérationnels privés exclus.
Il ne recalcule pas la notation sémantique et ne relance pas le modèle.

Avec un accès autorisé au dépôt source fermé, vérification supplémentaire :
    PYTHONDONTWRITEBYTECODE=1 python3 verify-public-data.py --source-root CHEMIN_DU_DEPOT
Cette option vérifie les empreintes de tous les fichiers sources lus et la
reproduction exacte de la projection publique, sans écrire dans le dépôt.
build-public-data.py conserve cette projection explicite ; son option --output
doit désigner un nouveau dossier pour reconstruire les exports sans les écraser.

Ce paquet prépare une proposition de page. Il ne constitue pas une publication.
