#!/usr/bin/env python3
"""Verify the sanitized public package using Python's standard library only.

Default: check public counts, exact quotations, operator changes and absence of
private operational fields. With --source-root, also check every source hash
and reproduce the exact public projection from the private closed captures.
This is capture verification, not a new semantic score or model execution.
"""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import re


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def verify(data, proofs):
    require(data["schema"] == "datapredict-synthetic-incident-public-v6/1", "schema")
    cases = data["cases"]
    require(len(cases) == 30 and len({c["id"] for c in cases}) == 30, "thirty_unique_cases")
    require([c["index"] for c in cases] == list(range(30)), "exact_case_order")
    quotations = Counter()

    def check_response(response, pieces, kind):
        if response is None:
            return
        by_id = {p["id"]: p["text"] for p in pieces}
        require(len(by_id) == len(pieces), "duplicate_piece")
        for evidence in response["evidence"]:
            require(evidence["piece"] in by_id, "foreign_citation_piece")
            require(bool(evidence["quote"]) and evidence["quote"] in by_id[evidence["piece"]], "citation_not_exact")
            quotations[kind] += 1

    for case in cases:
        require(case["score"]["id"] == case["id"], "score_case_binding")
        require(set(case["field_verification"]) == {"service", "category", "impact", "urgency"}, "field_verification")
        for kind in ("response", "expected"):
            check_response(case[kind], case["input"]["pieces"], kind)
    require(sum(c["score"]["conform"] for c in cases) == data["summary"]["conform"] == 26, "conform_count")
    require(sum(bool(c["score"]["critical_errors"]) for c in cases) == data["summary"]["critical_responses"] == 4, "critical_count")
    require(sum(c["raw_model_conform"] is True for c in cases) == data["summary"]["raw_model_conform"], "raw_model_count")
    for split, size, conform in (("assisted_main", 20, 20), ("assisted_challenge", 10, 6)):
        group = [c for c in cases if c["split"] == split]
        require(len(group) == data["groups"][split]["planned"] == size, "group_denominator")
        require(sum(c["score"]["conform"] for c in group) == data["groups"][split]["conform"] == conform, "group_score")
    require([c["index"] for c in cases if not c["score"]["conform"]] == [22, 23, 26, 29], "four_failures")
    require([c["index"] for c in data["featured_cases"]] == [6, 0, 22, 23], "featured_order")
    require([c["index"] for c in data["error_cases"]] == [22, 23, 26, 29], "all_errors_explained")
    for item in data["featured_cases"] + data["error_cases"]:
        case = cases[item["index"]]
        require(item["id"] == case["id"], "featured_case_binding")
        check_response({"evidence": item["quotes"]}, case["input"]["pieces"], "explanation")
    scores = proofs["score-acceptance02.json"]["outcomes"]
    require(len(scores) == 30, "score_proof_count")
    for case, original in zip(cases, scores):
        require(all(case[k] == original[k] for k in ("id", "split", "mode", "response", "expected", "score", "wall_seconds")), "public_score_projection")
    require(proofs["operator-simulations.json"] == data["operator_demo"], "operator_proof")
    require(proofs["operational-history.json"] == data["history"], "history_proof")
    events = data["operator_demo"]["events"]
    require([e["action"] for e in events] == ["confirm", "correct", "reject"], "three_operator_actions")
    require([e["case_index"] for e in events] == [0, 22, 20], "operator_case_indices")
    for event in events:
        case = cases[event["case_index"]]
        decision = event["decision"]
        require(event["case_id"] == case["id"] and event["initial"] == case["response"], "operator_initial_binding")
        require(event["expected"] == case["expected"] and event["pieces"] == case["input"]["pieces"], "operator_case_context")
        require(event["timestamp"] == decision["timestamp"] and event["action"] == decision["action"], "operator_decision_binding")
        require(event["simulated"] is True and decision["simulated"] is True, "operator_simulated")
        require(decision["counts_as_real_human_review"] is False and decision["external_action"] is False, "operator_scope")
        require(event["initial_unchanged"] is True, "initial_preserved")
        require(event["changes"] == decision["changes"], "operator_changes_binding")
        if event["action"] == "reject":
            require(decision["final_response"] is None and event["changes"] == {}, "rejected_without_action")
        else:
            final = decision["final_response"]
            changes = {k: {"before": event["initial"][k], "after": final[k]} for k in final if final[k] != event["initial"][k]}
            require(changes == event["changes"], "operator_exact_changes")
            check_response(final, event["pieces"], "operator_final")
            if event["action"] == "correct":
                require(final == event["expected"], "simulated_correction_matches_annotation")
    require(data["summary"]["human_review_count"] == data["operator_demo"]["real_human_review_count"] == 0, "zero_real_reviews")
    old = data["history"]["acceptance01"]
    require(old["planned"] == 30 and old["http_status_counts"] == {"200": 5, "503": 25}, "first_failed_run_retained")
    require(old["raw_model_not_executed"] == 25, "no_inference_on_frontend_refusal")
    stop = data["history"]["intentional_stop"]
    require(stop["intentional"] and stop["outside_acceptance_denominator"] and stop["http_status"] == 503 and stop["error"]["code"] == "service_stopping", "intentional_stop_scope")
    forbidden_keys = {"pid", "pgid", "uuid", "hostname", "request_id", "operator_record", "proposal_file", "record", "wire_request", "wire_sha256", "generations", "source_log_excerpt", "gpu_before", "gpu_after", "fan_observations", "cpu_process_deltas", "backend_command", "client_stdout", "client_stderr", "argv", "lora_adapter", "model_revision"}

    def scan(value):
        if isinstance(value, dict):
            require(not (set(value) & forbidden_keys), "private_operational_field")
            for child in value.values():
                scan(child)
        elif isinstance(value, list):
            for child in value:
                scan(child)
        elif isinstance(value, str):
            require(not re.search(r"(?:/home/|/media/|/tmp/|/proc/|GPU-[0-9a-f]{8}|\bpid[=: ]+\d+)", value, re.I), "private_machine_value")
            require(not re.match(r"^[A-Za-z]:[\\/]", value), "absolute_windows_path")

    scan(data)
    for proof in proofs.values():
        scan(proof)
    return {"state": "VALIDÉ_CONTROLE_EXPORT", "cases": 30, "main_conform": "20/20", "challenge_conform": "6/10",
            "critical_responses": 4, "exact_citations_checked": dict(quotations), "operator_actions": 3,
            "human_review_count": 0, "new_model_calls": 0,
            "scope": "Comptes, citations littérales, projections de scores, décisions simulées et assainissement. Ne refait pas la notation sémantique."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--source-root", type=Path)
    args = parser.parse_args()
    directory = args.directory.resolve()
    data = json.loads((directory / "public-data.json").read_text())
    proofs = {p.name: json.loads(p.read_text()) for p in sorted((directory / "proofs").glob("*.json"))}
    result = verify(data, proofs)
    manifest = directory / "SHA256SUMS-public.txt"
    if manifest.exists():
        verified = 0
        for line in manifest.read_text().splitlines():
            expected, name = line.split("  ", 1)
            require(not Path(name).is_absolute() and ".." not in Path(name).parts, "relative_public_path")
            require(hashlib.sha256((directory / name).read_bytes()).hexdigest() == expected, "public_file_hash_changed:" + name)
            verified += 1
        result["public_files_verified"] = verified
    if args.source_root:
        source_root = args.source_root.resolve()
        for name, expected in data["provenance"]["source_sha256"].items():
            require(not Path(name).is_absolute() and ".." not in Path(name).parts, "relative_source_path")
            require(hashlib.sha256((source_root / name).read_bytes()).hexdigest() == expected, "source_hash_changed:" + name)
        spec = importlib.util.spec_from_file_location("public_builder", directory / "build-public-data.py")
        builder = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(builder)
        expected_data, expected_proofs = builder.project(source_root)
        require(data == expected_data and proofs == expected_proofs, "source_projection_changed")
        result["source_files_verified"] = len(data["provenance"]["source_sha256"])
        result["exact_source_projection"] = True
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
